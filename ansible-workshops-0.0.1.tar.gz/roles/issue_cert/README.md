<<<<<<< HEAD
# Ansible Collection - ansible.workshops

This is the **issue_cert** role (e.g. `ansible.workshops.issue_cert`)

**Purpose**: update lets encrypt SSL cert for Ansible Automation Platform
=======
# Ansible Collection - ipvsean.ansible_platform_ssl

update lets encrypt SSL cert for Ansible Automation Platform

>>>>>>> syncing cert test


## Example

<<<<<<< HEAD
The included Ansible Playbook is injecting the role directly from the `roles` directory, this is not how you would use it in production (you would use `ansible.workshops.issue_cert`)

=======
>>>>>>> syncing cert test
```ansible-playbook update_cert.yml -e "dns_name=ansible.demoredhat.com"```
